library(testthat)
library(Boruta)

test_check("Boruta")

