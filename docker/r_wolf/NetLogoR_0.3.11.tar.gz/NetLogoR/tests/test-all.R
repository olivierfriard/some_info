library(magrittr)
library(testthat)
test_check("NetLogoR")
# to test manually, use test_package("NetLogoR")
