The file "Wolf-Sheep-Predation.R" contains the code to run the model built using a for loop to manage time.
The code for the model is in the same file.

The file "Wolf-Sheep-Predation-SpaDES.R" contains the code to run the model built using the pacakage SpaDES and its scheduler function to manage time.
The SpaDES version of the model (called "module") is in the folder "WolfSheepPredation".