Wolf sheep predation
Original model by Wilensky (1997) NetLogo Wolf Sheep Predation model
http://ccl.northwestern.edu/netlogo/models/WolfSheepPredation
