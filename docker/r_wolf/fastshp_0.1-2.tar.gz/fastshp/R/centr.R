centr <- function(shp) .Call(shp_centroids, shp)

