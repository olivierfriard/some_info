closest <- function(shp, x, y) .Call(shp_closest, shp, x, y)
